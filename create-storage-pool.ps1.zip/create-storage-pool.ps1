﻿

Configuration InstallRavenDBOnDiskPool
{
  param ($MachineName,$RavenDownloadPath)

  Node $MachineName
  {
	Script InstallRavenDBOnDiskPool { 
		SetScript = { 
            $PoolCount = Get-PhysicalDisk -CanPool $True
            $DiskCount = $PoolCount.count
            $PoolName = "RavenData"
            $PhysicalDisks = Get-StorageSubSystem -FriendlyName "Storage Spaces*" | Get-PhysicalDisk -CanPool $True
            New-StoragePool -FriendlyName $PoolName -StorageSubsystemFriendlyName "Storage Spaces*" -PhysicalDisks $PhysicalDisks |New-VirtualDisk -FriendlyName $PoolName -NumberOfColumns $DiskCount -ResiliencySettingName simple –UseMaximumSize -Interleave 65536 | Initialize-Disk -Confirm:$False -PassThru |New-Partition -DriveLetter F -UseMaximumSize |Format-Volume -FileSystem NTFS -NewFileSystemLabel $PoolName -AllocationUnitSize 65536 -Confirm:$false
            wget $RavenDownloadPath -UseBasicParsing -OutFile ravenInstall.exe
            .\ravenInstall.exe /quiet  /msicl "RAVEN_TARGET_ENVIRONMENT=DEVELOPMENT TARGETDIR=F:\ INSTALLFOLDER=C:\RavenDB RAVEN_INSTALLATION_TYPE=SERVICE REMOVE=IIS ADDLOCAL=Service"
        } 

		TestScript = { 
			Test-Path F:\ 
		} 
		GetScript = { <# This must return a hash table #> }          }   
    }
	
} 